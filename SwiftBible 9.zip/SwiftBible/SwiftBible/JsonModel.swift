//
//  JsonModel.swift
//  swiftyjson
//
//  Created by Pio on 16/04/18.
//  Copyright © 2018 Pio. All rights reserved.
//

import Foundation


struct JsonModel : Codable{
    var abbrev : String =  ""
    var book : String = ""
    var chapters: String = ""
    
    init(){
        
    }
    
    init(json:JSON){
        abbrev = json["abbrev"].stringValue
        book = json["name"].stringValue
        chapters = json["chapters"].stringValue
    }
}
