//
//  PreviewViewController.swift
// TestMakeAndPrintPDF
//
//  Created by pioon 06/02/2017.
//  Copyright © 2017 . All rights reserved.
//

import UIKit
import WebKit
import QuickLook

class PreviewViewController: UIViewController,WKNavigationDelegate,QLPreviewControllerDataSource,QLPreviewControllerDelegate{
    func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
        return fileURLs.count
        
    }
    
    func numberOfPreviewItemsInPreviewController(controller: QLPreviewController) -> Int {
        return fileURLs.count
    }
    
    
    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        return fileURLs[index]
    }
    
    
    
    @IBOutlet weak var webView: WKWebView!
    
    @IBOutlet weak var activityView: UIActivityIndicatorView!
    
    var pdfFile: String?
    
    let quickLookController = QLPreviewController()
    
    var fileURLs = [NSURL]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        activityView.startAnimating()
             prepareFileURLs()
       
            if QLPreviewController.canPreview(fileURLs[0]) {
                //quickLookController.currentPreviewItemIndex = indexPath.row
                navigationController?.pushViewController(quickLookController, animated: true)
            
                self.webView.load(URLRequest(url: fileURLs[0] as URL))
            
            webView.navigationDelegate = self
            
        } else {
            NSLog("Couldn't load PDF")
        }
        quickLookController.dataSource = self
        
        quickLookController.delegate = self
        
    }



func prepareFileURLs() {
        if let path = self.pdfFile {
        let url = URL(fileURLWithPath: path)
            fileURLs.append(url as NSURL)
        }
}
    
    

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        NSLog("didFinishNavigation")
        activityView.stopAnimating()
        //Assign the Web View as the View
        
        //view = webView
    }




func extractAndBreakFilenameInComponents(fileURL: NSURL) -> (fileName: String, fileExtension: String) {
    // Break the NSURL path into its components and create a new array with those components.
    let fileURLParts = fileURL.path!.components(separatedBy: "/")
    
    // Get the file name from the last position of the array above.
    let fileName = fileURLParts.last
    
    // Break the file name into its components based on the period symbol (".").
    let filenameParts = fileName?.components(separatedBy: ".")
    
    // Return a tuple.
    return (filenameParts![0], filenameParts![1])
}

func getFileTypeFromFileExtension(fileExtension: String) -> String {
    var fileType = ""
    
    switch fileExtension {
    case "docx":
        fileType = "Microsoft Word document"
        
    case "pages":
        fileType = "Pages document"
        
    case "jpeg":
        fileType = "Image document"
        
    case "key":
        fileType = "Keynote document"
        
    case "pdf":
        fileType = "PDF document"
        
        
    default:
        fileType = "Text document"
        
    }
    
    return fileType
}

   
    func previewControllerWillDismiss(_ controller: QLPreviewController) {
        print("The Preview Controller will be dismissed.")
    }
    
    private func previewControllerDidDismiss(controller: QLPreviewController) {
      //  tblFileList.deselectRowAtIndexPath(tblFileList.indexPathForSelectedRow!, animated: true)
        print("The Preview Controller has been dismissed.")
    }
    
    private func previewController(controller: QLPreviewController, shouldOpenURL url: NSURL, forPreviewItem item: QLPreviewItem) -> Bool {
        if item as! NSURL == fileURLs[0] {
            return true
        }
        else {
            print("Will not open URL ")
        }
        
        return false
    
    }
    
}
