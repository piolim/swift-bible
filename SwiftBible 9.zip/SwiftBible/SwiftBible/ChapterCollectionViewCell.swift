//
//  ChapterCollectionViewCell.swift
//  Bible
//
//  Created by Pio on 12/1/19.
//  Copyright © 2019 pio. All rights reserved.
//

import UIKit

class ChapterCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var chapterLbl: UILabel!
    
    func SetCell(row: Int, chapter: String?){
        
        //verselbl.text = ("\(row + 1)")
        chapterLbl.textAlignment = .left
        chapterLbl.highlightedTextColor = UIColor.white
        chapterLbl.textColor = UIColor.black
        chapterLbl.text = ("\(row+1). ") + chapter!
        
        
    }
    
    
    func SetCell(chapter: String?){
    chapterLbl.text = chapter
        
        
    }

    
    
    
}
