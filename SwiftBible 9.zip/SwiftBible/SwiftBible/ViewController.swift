//
//  ViewController.swift
//  Bible
//
//  Created by Pio on 4/1/19.
//  Copyright © 2019 pio. All rights reserved.
//

import UIKit
import WebKit
import PDFKit

class ViewController: UIViewController,WKNavigationDelegate{

    
    var bibleArr : [JsonModel] = []
    var bibleChapterArr : [Bibles] = []
    var bibleChapterSearchArr : [Bibles] = []
    var myData: MyData!
    var book: Int = 0
    var searchbible = false
    var count = 0
    var pdfFile : String?
    
    
    @IBOutlet weak var webView: WKWebView!
    
    @IBOutlet weak var activityView: UIActivityIndicatorView!
    
    var dict = [String:String]()
    
    
    
    
     override func viewDidLoad() {
        super.viewDidLoad()
       title = bibleChapterArr[0].title
        if title == ""        {
           // let alert = Alert.self
            //alert.showUnableToRetrieveDataAlert(on: self, message: "Title is blank")
            title = myData.name
            
        }
        
        activityView.startAnimating()
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "PDF", style: .plain, target: self, action: #selector(exportHTMLContentToPDF))
       }
    
    
    func fileToURL(file: String) -> URL? {
        // Get the full path of the file
        guard let document = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first) else {
            return nil
        }
        return URL(fileURLWithPath: document+file)
    }
    
    
    
    // MARK: - WKNavigationDelegate
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        NSLog("didFinishNavigation")
        //self.webView.scrollView.contentOffset = CGPointMake(0, 100);
        activityView.stopAnimating()
        
    }
    
    // Sometimes, this delegate is called before the image is loaded. Thus we give it a bit more time.
    /*DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
     let path = self.createPDF(formatter: webView.viewPrintFormatter(), filename: "MyPDFDocument")
     print("PDF location: \(path)")
     self.pdfFile = path
     self.navigationItem.rightBarButtonItem?.isEnabled = true
     }*/
    // }
    @objc func exportHTMLContentToPDF(sender: UIBarButtonItem) {
        var filename = title! + ".pdf"
        createPdfFromView(aView: webView!, saveToDocumentsWithFileName: filename)
        if let documentDirectories = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first {
            let documentsFileName = documentDirectories + "/" + filename
            debugPrint(documentsFileName)
        
        pdfFile = documentsFileName
        }
         performSegue(withIdentifier: "ViewToPreview", sender:  (pdfFile))
        //pdfDataWithWebView(webView: webView!, view:self.view, filename: filename)
        
    }
    
    @objc func share() {
        
        performSegue(withIdentifier: "ViewToPreview", sender:  (pdfFile))
      
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // If this gives a sandbox error, check:
        // http://stackoverflow.com/a/25973953/1085556
        /*let path = Bundle.main.path(forResource: "test", ofType: "html")
        let url = URL(fileURLWithPath: path!)
        self.webView.load(URLRequest(url: url))*/
        
        let html = """
        <html>
        <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style> body { font-size: 200%; } </style>
        </head>
        <body>
        """
        var htmlstring = ""
       // DispatchQueue.global().async {
            for i in 0...self.bibleChapterArr.count-1 {
                
                if i == 0 {
                    htmlstring += html
                    htmlstring += (self.bibleChapterArr[i].chapters)
                    //print(htmlstring)
                }
                else {
                    
                    htmlstring += (self.bibleChapterArr[i].chapters)
                }
                
                htmlstring = htmlstring.replacingOccurrences(of: "{", with: "")
                htmlstring = htmlstring.replacingOccurrences(of: "}", with: "")
                
            }
            
            let html1 = """
        </body>
        </html>
        """
            htmlstring += html1
            print(htmlstring)
        self.webView.loadHTMLString(htmlstring, baseURL: nil)
        self.webView.navigationDelegate = self
        
        }

        
    //    DispatchQueue.main.async {
              //activity.stopAnimating()
  //      }
        
//}
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "ViewToPreview" {
           // self.previewBtn.isEnabled = false
            let previewViewController = segue.destination as! PreviewViewController
            previewViewController.pdfFile = self.pdfFile
        }
    }
}

func createPdfFromView(aView: UIView, saveToDocumentsWithFileName fileName: String)
{
    
    let pdfData = NSMutableData()
    UIGraphicsBeginPDFContextToData(pdfData, aView.bounds, nil)
    UIGraphicsBeginPDFPage()
    
    guard let pdfContext = UIGraphicsGetCurrentContext() else {
        print("ERROR: ",(#function))
        return }
    
    aView.layer.render(in: pdfContext)
    UIGraphicsEndPDFContext()
    
    if let documentDirectories = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first {
        let documentsFileName = documentDirectories + "/" + fileName
        debugPrint(documentsFileName)
        pdfData.write(toFile: documentsFileName, atomically: true)
        let filePath = documentsFileName
        var fileSize : UInt64
        
        do {
            //return [FileAttributeKey : Any]
            let attr = try FileManager.default.attributesOfItem(atPath: filePath)
            fileSize = attr[FileAttributeKey.size] as! UInt64
            
            //if you convert to NSDictionary, you can get file size old way as well.
            let dict = attr as NSDictionary
            fileSize = dict.fileSize()
            print("fileSize = \(fileSize)")
        } catch {
            print("Error: \(error)")
        }
        
        print("SAVED: \(documentsFileName)")
        //pdfFile =  documentsFileName
        
    }
    //performSegue(withIdentifier: "ViewToPreview", sender:  (pdfFile))

    
}

    
    
    
extension String {
    func deletingPrefix(_ prefix: String) -> String {
        guard self.hasPrefix(prefix) else { return self }
        return String(self.dropFirst(prefix.count))
    }
}

