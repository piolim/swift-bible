//: Playground - noun: a place where people can play

import UIKit

class MyData {
    var name : String
    var book : Int
    var chapter: Int
    var verse :Int
    var indexPath : IndexPath
    
    
    
    init(name:String, book : Int, chapter : Int,verse:  Int, indexPath: IndexPath) {
        self.name = name
        self.book = book
        self.chapter = chapter
        self.verse = verse
        self.indexPath = indexPath
    }
    
    
}

class ActivityCntrl {
    
    var myActivity : Bool
    
    init(myActivity: Bool) {
        self.myActivity = myActivity
    }
    
}



class Bibles {
    var book : Int
    var name : String
    var chapters : String
    var chapter  : Int
    var verse : Int
    var title : String
    
    init(book: Int,name:String,chapters: String, chapter : Int,verse:  Int,title: String) {
        self.book = book
        self.name = name
        self.chapters =  chapters
        self.chapter = chapter
        self.verse = verse
        self.title  = title
    }
    
 
}
