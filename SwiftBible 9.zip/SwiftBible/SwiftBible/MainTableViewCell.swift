//
//  MainTableViewCell.swift
//  Bible
//
//  Created by Pio on 11/1/19.
//  Copyright © 2019 pio. All rights reserved.
//

import UIKit

class MainTableViewCell: UITableViewCell {

    @IBOutlet weak var maincell: UILabel!
    
    func SetCell(row: Int, chapter: String?){
        
        //verselbl.text = ("\(row + 1)")
        maincell.textAlignment = .left
        //maincell.highlightedTextColor = UIColor.white
       /// maincell.textColor = UIColor.black
        //cell.selectedBackgroundView.backgroundColor=[UIColor blackColor]
        maincell.text = ("\(row+1). ") + chapter!
        
        
    }
    
    
    func SetCell(chapter: String?){
        maincell.textAlignment = .center
        //maincell.highlightedTextColor = UIColor.blue
       // maincell.textColor = UIColor.white
        
        //verselbl.text = ("\(row + 1)")
        maincell.text = chapter
        
        
    }
}
