//
//  ChapterCollectionViewController.swift
//  Bible
//
//  Created by Pio on 12/1/19.
//  Copyright © 2019 pio. All rights reserved.
//

import UIKit

private let reuseIdentifier = "Cell"

class ChapterCollectionViewController: UICollectionViewController {
    
    var bibleChapterArr : [Bibles] = []
    var bibleChapterSearchArr : [Bibles] = []
    var cntBook = 0
    var cntVerse = 0
     var searchbible = false
    var myData : MyData!
    var verseToSearch : String?
    var bibleArr : [Bibles] =  []
    var bibleRepeatArr : [Bibles] =  []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
         title = myData.name
        OpenChapterBible()
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Register cell classes
        self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)

        // Do any additional setup after loading the view.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource
    func OpenChapterBible(){
        let activity = UIActivityIndicatorView(style: .whiteLarge)
        activity.color = UIColor.blue
        self.view.addSubview(activity)
        activity.frame = self.view.frame
        activity.center = self.view.center
        activity.startAnimating()
        
        let path = Bundle.main.path(forResource: "en_kjv", ofType: "json")
        let url = URL(fileURLWithPath: path!)
        
        //let url = URL(string: "https://restcountries.eu/rest/v2/all")
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else { return }
            do{
                let json = try JSON(data:data)
                //print(json)
                let results = json[]
                var i:Int = 0
                var chapter = 0
                var verses = 0
               
                
                //var i = 0
                
                // DispatchQueue.global().async {
                for arr in results.arrayValue{
                    for (key,value) in arr {
                        
                        if key == "abbrev" {
                            //print("\(self.cntBook)---\(value)")
                            self.cntBook += 1
                        }
                        if key == "chapters" {
                            //   self.bibleChapterArr.append("\(value)")
                            // self.bibleChapterSearchArr.append("\(value)")
                            
                        }
                        if key == "name" {
                            let bible  = Bibles(book: i,name:"\(value)",chapters:"\(value)",chapter: i, verse: i, title: "")
                            //print ("\(key)")
                            // print ("\(value)")
                             print ("\(i)---\(value)")
                        }
                        
                    }
                    i += 1
                    
                }
                
                //}
                
                //DispatchQueue.main.async {
                //self.tableView.reloadData()
                //   activity.stopAnimating()
                //}
                 var repeatChapter = 0
                
                i = 0
                let k = self.myData.chapter
                
                // activity.startAnimating()
                // DispatchQueue.global().async {
            //    for k in 0...(self.cntBook) {
                    chapter = 0
                    for arr in results[k,"chapters"].arrayValue{
                        for (key,value) in arr {
                            
                            // print ("---\(key) -- \(value)----")
                            //no of verses
                            if Int(key) == 0 {
                                verses = 0
                            }
                            
                            var bible  = Bibles(book: k,name:"---",chapters: "\(value)",chapter: chapter, verse: verses, title: "")
                            
                            repeatChapter += 1
                            
                            if repeatChapter == 1 {
                                
                                self.bibleRepeatArr.append(bible)
                            }
                            
                            self.bibleChapterArr.append(bible)
                            
                            let biblesearch  = Bibles(book: k,name:"---",chapters: "\(value)", chapter: chapter, verse: verses, title: "")
                            self.bibleChapterSearchArr.append(biblesearch)
                            verses += 1
                            
                            
                            print("book: \(k) chapter : \(chapter) verse : \(verses)  key : \(key)")
                        }
                        //no of chapter
                   //         print("book: \(self.book), chapter : \(chapter) verse : \(verses)  key : \(key)")
                        
                        chapter += 1
                        repeatChapter = 0
                    }
         //           print("book: , chapter : \(chapter) verse : \(verses)  key : ")
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                    activity.stopAnimating()
                }
            }catch{
                print(error.localizedDescription)
                }
            
            }.resume()
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "ChapterToDetail" {
            let destVC = segue.destination as! DetailsTableViewController
            destVC.myData = (sender as! MyData)
        }
        
        if segue.identifier == "MasterToView" && searchbible == true {
            let destVC = segue.destination as! ViewController
            
            destVC.bibleChapterArr = (sender as! [Bibles])
            //destVC.myData = (sender as! MyData)
            
        }
        
    }
    

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return bibleRepeatArr.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // make a cell for each cell index path
            // get a reference to our storyboard cell
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "chapterCell", for: indexPath as IndexPath) as! ChapterCollectionViewCell
        //cell.layer.borderColor = UIColor.black.cgColor
        //cell.layer.borderWidth = 1
        cell.layer.cornerRadius = 20

        
        // Use the outlet in our custom class to get a reference to the UILabel in the cell
        cell.chapterLbl.text = ("\(self.bibleRepeatArr[indexPath.item].chapter+1)")
        
            return cell
        }
        
        // MARK: - UICollectionViewDelegate protocol
        
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            // handle tap events
        

    //    let mydata = MyData.init(name: "Bible", book: 0, chapter: 0, verse: 0, indexPath: indexPath)
        myData.book = bibleRepeatArr[indexPath.item].book
        myData.chapter = bibleRepeatArr[indexPath.item].chapter
        //mydata.name = bibleArr[bibleRepeatArr[indexPath.item].book].name
        //mydata.verse  = bibleRepeatArr[indexPath.item].verse
        //mydata.indexPath  = indexPath
        // bibleArr[0].chapter = bibleChapterArr[indexPath.row].chapter
        
        
       // performSegue(withIdentifier: "MasterToDetail", sender:  (mydata))
        
        performSegue(withIdentifier: "ChapterToDetail", sender:  (myData))
        
            print("You selected cell #\(indexPath.item)!")
        }
    

    // MARK: UICollectionViewDelegate

    // change background color when user touches cell
    override func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.backgroundColor = UIColor.red
    }
    
    // change background color back when user releases touch
    override func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        cell?.backgroundColor = UIColor.blue
    }

    

    /*
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        return false
    }

    override func collectionView(_ collectionView: UICollectionView, performAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) {
    
    }
    */

}
