//
//  DetailsTableViewController.swift
//  test4
//
//  Created by pio on 1/12/18.exsectio
//  Copyright © 2018 pio. All rights reserved.
//

import UIKit
import SafariServices

class DetailsTableViewController: UITableViewController,UITextFieldDelegate {

    @IBOutlet weak var txtSearchBar: UITextField!
    
   
    var bibleArr : [JsonModel] = []
    var bibleChapterArry : [Bibles] = []
    var bibleChapterSearchArry : [Bibles] = []
    var myData: MyData!
    var book: Int = 0
    var searchbible = false
     var count = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = myData.name + " \(myData.chapter + 1)"
        book = myData.book
        
        OpenJsonBible()
       
        tableView.estimatedRowHeight = tableView.rowHeight
        tableView.rowHeight = UITableView.automaticDimension
        txtSearchBar.delegate = self
        txtSearchBar.addTarget(self, action: #selector(searchRecords(_ :)), for: .editingChanged)
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .action, target: self, action: #selector(share))
        
        }
    
    @objc func share() {
        let activity = UIActivityIndicatorView(style: .whiteLarge)
        activity.color = UIColor.blue
        self.view.addSubview(activity)
        activity.frame = self.view.frame
        activity.center = self.view.center
        activity.startAnimating()
        
        //DispatchQueue.global().async {
        //    for i in 0...(self.bibleChapterArry.count-1){
          //      let activity = UIActivityViewController(activityItems: [self.bibleChapterArry[i].chapters], applicationActivities: [])
              ///  self.present(activity, animated: true)
        //    }
        //}
        
        DispatchQueue.main.async {
            activity.stopAnimating()
            
           
        }
        performSegue(withIdentifier: "DetailToView", sender:  (bibleChapterArry))
        activity.stopAnimating()
    }

    
    


//MARK:- UITextFieldDelegate
func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    txtSearchBar.resignFirstResponder()
    return true
}
//MARK:- searchRecords
@objc func searchRecords(_ textField: UITextField) {
    self.bibleChapterArry.removeAll()
    if textField.text?.count != 0 {
        for arr in bibleChapterSearchArry{
            if let chapterToSearch = textField.text{
                let range = arr.chapters.lowercased().range(of: chapterToSearch, options: .caseInsensitive, range: nil, locale: nil)
                if range != nil {
                    self.bibleChapterArry.append(arr)
                    searchbible = true
                    navigationItem.rightBarButtonItem?.isEnabled = true
                }
            }
        }
    } else {
        for arr in bibleChapterSearchArry {
            bibleChapterArry.append(arr)
            searchbible = false
            navigationItem.rightBarButtonItem?.isEnabled = false
        }
    }
    self.tableView.reloadData()
    
}

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "DetailToView" {
            let destVC = segue.destination as! ViewController
            destVC.bibleChapterArr = (sender as! [Bibles])
        }
        
  
        
    }
    
    func OpenJsonBible(){
        let activity = UIActivityIndicatorView(style: .whiteLarge)
        activity.color = UIColor.blue
        self.view.addSubview(activity)
        activity.frame = self.view.frame
        activity.center = self.view.center
        activity.startAnimating()
        let path = Bundle.main.path(forResource: "en_kjv", ofType: "json")
        let url = URL(fileURLWithPath: path!)
        
        //let url = URL(string: "https://restcountries.eu/rest/v2/all")
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else { return }
            do{
                let json = try JSON(data:data)
                //print(json)
                let results = json[]
                var verses = 0
                //var chapter = self.myData.chapter
               // for k in 0...1 {
                var chapter = 0
                    for arr in results[self.book,"chapters"].arrayValue{
                        for (key,value) in arr {
                            
                            // print ("---\(key) -- \(value)----")
                            //no of verses
                            if Int(key) == 0 {
                                verses = 0
                            }
                            
                            if self.myData.chapter == chapter {
                                if self.myData.verse <= verses {
                                    let bible  = Bibles(book: self.book,name: self.myData.name,chapters: "\(value)",chapter: chapter, verse: verses, title: self.title!  )
                            self.bibleChapterArry.append(bible)
                                    let biblesearch  = Bibles(book: self.book,name: self.myData.name,chapters: "\(value)", chapter: chapter, verse: verses, title: self.title!)
                            self.bibleChapterSearchArry.append(biblesearch)
                            
                            //print("book: \(self.book), chapter : \(chapter) verse : \(verses)  key : \(key)")
                                }
                                verses += 1
                            }
                        }
                        //no of chapter
                       //print("book: \(self.book), chapter : \(chapter),verse : \(verses)")
                       chapter += 1
                    }
                    
                //print("book: \(k), count i: \(i)   j: \(j) chapter : \(chapter) verse : \(verses)")
                //no of book
               // }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    activity.stopAnimating()
                    
                }
            }catch{
                print(error.localizedDescription)
            }
            }.resume()
    }
    
  
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bibleChapterArry.count
 
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DetailCell") as! DetailsTableViewCell
        //if cell == nil {
          //  cell = UITableViewCell(style: .default, reuseIdentifier: "DetailCell") as! DetailsTableViewCell
        //}
        cell.SetCell(row: self.bibleChapterArry[indexPath.row].verse,chapter: self.bibleChapterArry[indexPath.row].chapters)
        if searchbible == true {
            title = self.bibleChapterArry[indexPath.row].title
            cell.contentView.backgroundColor = .yellow
        }
        else {
            cell.contentView.backgroundColor = .cyan
            //title = myData.name
        }
       
        return cell
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var name = bibleChapterArry[indexPath.row].name.lowercased()
        //let indexFrom = name.startIndex
        let indexTo = name.index(name.startIndex, offsetBy: 1)
        for nam in name {
            if nam == " " {
                
                name.insert(contentsOf: "-", at: indexTo)
                var biblename = ""
                for nam in name {
                    if nam != " " {
                        biblename.append(nam)
                    }
            
                }
                name = biblename
            }
        }
        //insert(name[name.index(name.startIndex, offsetBy: 1)])
        let chapter = bibleChapterArry[indexPath.row].chapter + 1
        

       let searchURL: String = "http://www.biblestudytools.com/commentaries/matthew-henry-complete/" + name + ("/\(chapter).html")
        let URL = NSURL(string: searchURL)
        if URL == nil {
            Alert.showUnableToRetrieveDataAlert(on: self,message: name)
            return
        }
        else {
            ///let safariVC = SFSafariViewController(url: URL! as URL)
           // safariVC.delegate = self
           // present(safariVC, animated: true, completion: nil)
            }
         //performSegue(withIdentifier: "DetailToView", sender:  (mydata))
    }
    
   
}



extension DetailsTableViewController : SFSafariViewControllerDelegate {
    
    func safariViewControllerDidFinish(_ controller: SFSafariViewController) {
        controller.dismiss(animated: true, completion:nil)
    }

    
 }


