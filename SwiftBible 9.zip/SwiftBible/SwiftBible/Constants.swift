//
//  Constants.swift
//  Alert-Refactor
//
//  Created by Sean Allen on 7/15/18.
//  Copyright © 2018 Sean Allen. All rights reserved.
//

import Foundation
import UIKit

struct Colors {
    static let pRed    = UIColor(red: 255/255, green: 71/255, blue: 56/255, alpha: 1)
    static let pBlue    = UIColor(red: 56/255, green: 71/255, blue: 255/255, alpha: 1)
     static let pGreen   = UIColor(red: 71/255, green: 255/255, blue: 56/255, alpha: 1)
}


struct Fonts {
    static let avenirNextMedium = "AvenirNext-Medium"
}
