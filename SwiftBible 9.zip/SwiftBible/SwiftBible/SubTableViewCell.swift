//
//  SubTableViewCell.swift
//  Bible
//
//  Created by Pio on 11/1/19.
//  Copyright © 2019 pio. All rights reserved.
//

import UIKit

class SubTableViewCell: UITableViewCell {

    @IBOutlet weak var subCell: UILabel!
    
    func SetCell(row: Int, chapter: String?){
        
        //verselbl.text = ("\(row + 1)")
   //     subCell.textAlignment = .left
   //     subCell.highlightedTextColor = UIColor.white
       // subCell.textColor = UIColor.black
        subCell.text = ("\(row+1).  ") + chapter!
        
        
    }
    
    
    func SetCell(chapter: String?){
        subCell.textAlignment = .center
        subCell.highlightedTextColor = UIColor.blue
        subCell.textColor = UIColor.white
        
        //verselbl.text = ("\(row + 1)")
        subCell.text = chapter
        
        
    }
}
