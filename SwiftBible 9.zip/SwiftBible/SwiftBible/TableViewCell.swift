//
//  TableViewCell.swift
//  test4
//
//  Created by pio on 1/12/18.
//  Copyright © 2018 pio. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    
    @IBOutlet weak var nameLabel: UILabel!
    
   
    @IBOutlet weak var verselbl: UILabel!
    
    func SetCell(row: Int, chapter: String?){
        
        verselbl.text = ("\(row + 1)")
        nameLabel.text = chapter
       
    
    }
}



