//
//  DetailsTableViewCell.swift
//  test4
//
//  Created by pio on 1/12/18.
//  Copyright © 2018 pio. All rights reserved.
//

import UIKit

class DetailsTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var versebl: UILabel!
    
    @IBOutlet weak var biblechapterlbl: UILabel!
    
    func SetCell(row: Int, chapter: String?){
        
        versebl?.numberOfLines = 1
        biblechapterlbl?.numberOfLines = 0
        versebl.text = ("\(row + 1)")
        biblechapterlbl.text = chapter
        
    }
    
    
}

