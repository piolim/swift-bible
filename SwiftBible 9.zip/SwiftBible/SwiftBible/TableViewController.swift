//
//  TableViewController.swift
//  test4
//
//  Created by pio on 1/12/18.
//  Copyright © 2018 pio. All rights reserved.
//

import UIKit


class TableViewController: UITableViewController,UITextFieldDelegate {

    
    @IBOutlet weak var txtSearchBar: UITextField!
    
    var bibleChapterArr : [Bibles] = []
    var bibleChapterSearchArr : [Bibles] = []
    var cntBook = 0
    var cntVerse = 0
    var cntChapter = 0
    var searchbible = false
    var myData : MyData!
    var verseToSearch : String?
   // var activityCntrl : ActivityCntrl!
    //var activityIndicatorView : UIActivityIndicatorView
    
    var bibleArr : [Bibles] =  []
    var bibleSearchArr : [Bibles] =  []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        OpenJsonBible()
        
        tableView.estimatedRowHeight = tableView.rowHeight
        tableView.rowHeight = UITableView.automaticDimension
        txtSearchBar.delegate = self
        txtSearchBar.addTarget(self, action: #selector(searchRecords(_ :)), for: .editingChanged)

       // addNavBarImage()
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .action, target: self, action: #selector(share))
        navigationItem.rightBarButtonItem?.isEnabled = false
        
    }
    
    
    
    @objc func share() {
        let activity = UIActivityIndicatorView(style: .whiteLarge)
        activity.color = UIColor.blue
        self.view.addSubview(activity)
        activity.frame = self.view.frame
        activity.center = self.view.center
        activity.startAnimating()
        
        DispatchQueue.global().async {
            for i in 0...(self.bibleChapterArr.count-1){
                let activity = UIActivityViewController(activityItems: [self.bibleChapterArr[i].chapters], applicationActivities: [])
          //      self.present(activity, animated: true)
                
               
        }
        
        DispatchQueue.main.async {
            activity.stopAnimating()
            }
        }
            performSegue(withIdentifier: "MasterToView", sender:  (myData))
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        
       if segue.identifier == "MasterToDetail" {
            let destVC = segue.destination as! DetailsTableViewController
        destVC.myData = (sender as! MyData)
            }
        
        if segue.identifier == "MasterToView" {
            let destVC = segue.destination as! ViewController
            destVC.myData = (sender as! MyData)
        }
      
        
    }
 
    
    
    //MARK:- UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtSearchBar.resignFirstResponder()
        return true
    }
    //MARK:- searchRecords
    @objc func searchRecords(_ textField: UITextField) {
    //
        self.bibleChapterArr.removeAll()
        if textField.text?.count != 0 {
            for arr in bibleChapterSearchArr{
                if let chapterToSearch = textField.text{
                    let range = arr.chapters.lowercased().range(of: chapterToSearch, options: .caseInsensitive, range: nil, locale: nil)
                    if range != nil {
                        self.bibleChapterArr.append(arr)
                        searchbible = true
                        navigationItem.rightBarButtonItem?.isEnabled = true
                    }
                }
            }
        } else {
            for arr in bibleChapterSearchArr {
                bibleChapterArr.append(arr)
                searchbible = false
                navigationItem.rightBarButtonItem?.isEnabled = false
                }
            }
        
        
        self.tableView.reloadData()
        
        
    }
    //
    
     
    func OpenJsonBible(){
        let activity = UIActivityIndicatorView(style: .whiteLarge)
        activity.color = UIColor.blue
        self.view.addSubview(activity)
        activity.frame = self.view.frame
        activity.center = self.view.center
        activity.startAnimating()
        
        let path = Bundle.main.path(forResource: "en_kjv", ofType: "json")
        let url = URL(fileURLWithPath: path!)
        
        //let url = URL(string: "https://restcountries.eu/rest/v2/all")
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else { return }
            do{
                let json = try JSON(data:data)
                //print(json)
                let results = json[]
                var i:Int = 0
               // var j:Int = 0
               // var book = 0
                var chapter = 0
                var verses = 0
                
                //var i = 0
                
                // DispatchQueue.global().async {
                    
                    for arr in results.arrayValue{
                    for (key,value) in arr {
                        
                        if key == "abbrev" {
                            //print("\(self.cntBook)---\(value)")
                            self.cntBook += 1
                        }
                        if key == "chapters" {
                            //   self.bibleChapterArr.append("\(value)")
                            // self.bibleChapterSearchArr.append("\(value)")
                            
                        }
                        if key == "name" {
                            let bible  = Bibles(book: i,name:"\(value)",chapters:"\(value)",chapter: i, verse: i, title: "")
                            //print ("\(key)")
                            // print ("\(value)")
                            self.bibleArr.append(bible)
                            //print ("\(i)---\(value)")
                        }
                        
                    }
                    i += 1
                   }
                    
                //}
                
                //DispatchQueue.main.async {
                    //self.tableView.reloadData()
                  //   activity.stopAnimating()
                //}
                
                i = 0
        
               // activity.startAnimating()
               // DispatchQueue.global().async {
                for k in 0...(self.cntBook) {
                    chapter = 0
                    for arr in results[k,"chapters"].arrayValue{
                        for (key,value) in arr {
                            
                            // print ("---\(key) -- \(value)----")
                            //no of verses
                            if Int(key) == 0 {
                                verses = 0
                            }
                            
                            
                            let bible  = Bibles(book: k,name:"---",chapters: "\(value)",chapter: chapter, verse: verses,title:"")
                                    self.bibleChapterArr.append(bible)
                                    
                            let biblesearch  = Bibles(book: k,name:"---",chapters: "\(value)", chapter: chapter, verse: verses, title: "")
                                    self.bibleChapterSearchArr.append(biblesearch)
                            verses += 1
                            
                            
                     //       print("book: \(self.book), chapter : \(chapter) verse : \(verses)  key : \(key)")
                        }
                        //no of chapter
                    ///    print("book: \(self.book), chapter : \(chapter) verse : \(verses)  key : \(key)")
                        
                        chapter += 1
                    }
                    
                   // print("book: \(self.book), chapter : \(chapter) verse : \(verses)  key : \(key)")
                    //no of book
                }
        //    }
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    activity.stopAnimating()
                    
                }
            }catch{
                print(error.localizedDescription)
            }
            }.resume()
        
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //print("1:  \(self.bibleArr.count)")
        return self.bibleChapterArr.count
       }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BibleCell") as! TableViewCell
       // if cell = nil {
         //   cell = UITableViewCell(style: .default, reuseIdentifier: "BibleCell") as! //TableViewCell
       // }
       // cell?.textLabel?.text = "";\(indexpath.row) " +
        cell.SetCell(row: indexPath.row,chapter: self.bibleChapterArr[indexPath.row].chapters)
        
        
        cell.textLabel?.numberOfLines = 0
        if searchbible == true {
        cell.contentView.backgroundColor = .yellow
        }
        else {
            cell.contentView.backgroundColor = .white
        }
        return cell
        
        }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        let mydata = MyData.init(name: "Bible", book: 0, chapter: 0, verse: 0, indexPath: indexPath)
            mydata.book = bibleArr[bibleChapterArr[indexPath.row].book].book
            mydata.chapter = bibleChapterArr[indexPath.row].chapter
            mydata.name = bibleArr[bibleChapterArr[indexPath.row].book].name
            mydata.verse  = bibleChapterArr[indexPath.row].verse
            mydata.indexPath  = indexPath
           // bibleArr[0].chapter = bibleChapterArr[indexPath.row].chapter
        
            
       performSegue(withIdentifier: "MasterToDetail", sender:  (mydata))
        
    }
}



//
/*
 
 
 
 
 
 
 
 
 */


//


