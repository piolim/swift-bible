//
//  MainTableViewController.swift
//  Bible
//
//  Created by Pio on 11/1/19.
//  Copyright © 2019 pio. All rights reserved.
//

import UIKit

class MainTableViewController: UITableViewController,UITextFieldDelegate{

    @IBOutlet weak var txtSearchBar: UITextField!
    
    var bibleChapterArr : [Bibles] = []
    var bibleChapterSearchArr : [Bibles] = []
    var cntBook = 0
    var cntVerse = 0
    var cntChapter = 0
    var searchbible = false
    var myData : MyData!
    var verseToSearch : String?
    var bibleArr : [Bibles] =  []
    var bibleSearchArr : [Bibles] =  []
    
    var mainBible = ["Old Testament","New Testament"]
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        OpenMainBible()
        
        txtSearchBar.delegate = self
        txtSearchBar.addTarget(self, action: #selector(searchRecords(_ :)), for: .editingChanged)
        
        // addNavBarImage()
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .action, target: self, action: #selector(share))
        navigationItem.rightBarButtonItem?.isEnabled = false
        
    }
    
    //MARK:- UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtSearchBar.resignFirstResponder()
        return true
    }
    //MARK:- searchRecords
    @objc func searchRecords(_ textField: UITextField) {
        //
        self.bibleChapterArr.removeAll()
        if textField.text?.count != 0 {
            for arr in bibleChapterSearchArr{
                if let chapterToSearch = textField.text{
                    let range = arr.chapters.lowercased().range(of: chapterToSearch, options: .caseInsensitive, range: nil, locale: nil)
                    if range != nil {
                        
                        self.bibleChapterArr.append(arr)
                        searchbible = true
                        navigationItem.rightBarButtonItem?.isEnabled = true
                    }
                }
            }
        } else {
            for arr in bibleChapterSearchArr {
                bibleChapterArr.append(arr)
                searchbible = false
                navigationItem.rightBarButtonItem?.isEnabled = false
            }
        }
        
        
        self.tableView.reloadData()
        
        
    }
    
    @objc func share() {
        let activity = UIActivityIndicatorView(style: .whiteLarge)
        activity.color = UIColor.blue
        self.view.addSubview(activity)
        activity.frame = self.view.frame
        activity.center = self.view.center
        activity.startAnimating()
        
        performSegue(withIdentifier: "MainToView", sender:  (bibleChapterArr))
        activity.stopAnimating()
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        
        if segue.identifier == "MainToSub" {
            let destVC = segue.destination as! SubTableViewController
            destVC.myData = (sender as! MyData)
        }
        
        if segue.identifier == "MasterToView" && searchbible == true {
            let destVC = segue.destination as! ViewController
            
            destVC.bibleChapterArr = (sender as! [Bibles])
            //destVC.myData = (sender as! MyData)
            
        }
        
        if segue.identifier == "MainToDetail" {
            let destVC = segue.destination as! DetailsTableViewController
            destVC.myData = (sender as! MyData)
        }
        
    }
    
    
    func OpenMainBible(){
        let activity = UIActivityIndicatorView(style: .whiteLarge)
        activity.color = UIColor.blue
        self.view.addSubview(activity)
        activity.frame = self.view.frame
        activity.center = self.view.center
        activity.startAnimating()
        
        let path = Bundle.main.path(forResource: "en_kjv", ofType: "json")
        let url = URL(fileURLWithPath: path!)
        
        //let url = URL(string: "https://restcountries.eu/rest/v2/all")
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else { return }
            do{
                let json = try JSON(data:data)
                //print(json)
                let results = json[]
                var i:Int = 0
                // var j:Int = 0
                // var book = 0
                var chapter = 0
                var verses = 0
                
                //var i = 0
                
                // DispatchQueue.global().async {
                
                for arr in results.arrayValue{
                    for (key,value) in arr {
                        
                        if key == "abbrev" {
                            //print("\(self.cntBook)---\(value)")
                            self.cntBook += 1
                        }
                        if key == "chapters" {
                            //   self.bibleChapterArr.append("\(value)")
                            // self.bibleChapterSearchArr.append("\(value)")
                            
                        }
                        if key == "name" {
                            let bible  = Bibles(book: i,name:"\(value)",chapters:"\(value)",chapter: i, verse: i, title: "")
                            //print ("\(key)")
                            // print ("\(value)")
                            self.bibleArr.append(bible)
                            //print ("\(i)---\(value)")
                        }
                        
                    }
                    i += 1
                }
                
                //}
                
                //DispatchQueue.main.async {
                //self.tableView.reloadData()
                //   activity.stopAnimating()
                //}
                
                i = 0
                
                // activity.startAnimating()
                // DispatchQueue.global().async {
                for k in 0...(self.cntBook) {
                    chapter = 0
                    for arr in results[k,"chapters"].arrayValue{
                        for (key,value) in arr {
                            
                            // print ("---\(key) -- \(value)----")
                            //no of verses
                            if Int(key) == 0 {
                                verses = 0
                            }
                            
                            
                            let bible  = Bibles(book: k,name:"---",chapters: "\(value)",chapter: chapter, verse: verses, title: "")
                            self.bibleChapterArr.append(bible)
                            
                            let biblesearch  = Bibles(book: k,name:"---",chapters: "\(value)", chapter: chapter, verse: verses, title: "")
                            self.bibleChapterSearchArr.append(biblesearch)
                            verses += 1
                            
                            
                            //       print("book: \(self.book), chapter : \(chapter) verse : \(verses)  key : \(key)")
                        }
                        //no of chapter
                        ///    print("book: \(self.book), chapter : \(chapter) verse : \(verses)  key : \(key)")
                        
                        chapter += 1
                    }
                    
                    // print("book: \(self.book), chapter : \(chapter) verse : \(verses)  key : \(key)")
                    //no of book
                }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    activity.stopAnimating()
                    
                }
            }catch{
                print(error.localizedDescription)
            }
            }.resume()
        
    }

    // MARK: - Table view data source

    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //print("1:  \(self.bibleArr.count)")
        if searchbible {
            return self.bibleChapterArr.count
        }
        else {
            return self.mainBible.count
        }
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //cell.textLabel?.numberOfLines = 0
        if searchbible {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MainCell") as! MainTableViewCell
            cell.SetCell(row: indexPath.row,chapter: self.bibleChapterArr[indexPath.row].chapters)
             title = txtSearchBar.text
            self.bibleChapterArr[indexPath.row].title = title!
            //tableView.estimatedRowHeight = tableView.rowHeight
            //tableView.rowHeight = UITableView.automaticDimension
            return cell
        }
        else {
            //cell.contentView.backgroundColor = .white
            title = "Bible"
            let cell = tableView.dequeueReusableCell(withIdentifier: "MainCell") as! MainTableViewCell
            cell.SetCell(chapter: self.mainBible[indexPath.row])
            return cell
        }
    }
    
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if searchbible == false {
        if indexPath.row == 0 {
        myData = MyData.init(name: mainBible[0], book: 0, chapter: 0, verse: 0, indexPath: indexPath)
        }
        else {
        myData = MyData.init(name: mainBible[1], book: 1, chapter: 0, verse: 0, indexPath: indexPath)
        }
            
        performSegue(withIdentifier: "MainToSub", sender:  (myData))
        }
        else {
        
        let mydata = MyData.init(name: "Bible", book: 0, chapter: 0, verse: 0, indexPath: indexPath)
        mydata.book = bibleArr[bibleChapterArr[indexPath.row].book].book
        mydata.chapter = bibleChapterArr[indexPath.row].chapter
        mydata.name = bibleArr[bibleChapterArr[indexPath.row].book].name
        mydata.verse  = bibleChapterArr[indexPath.row].verse
        mydata.indexPath  = indexPath
        // bibleArr[0].chapter = bibleChapterArr[indexPath.row].chapter
        
        
        performSegue(withIdentifier: "MainToDetail", sender:  (mydata))
        }
        
    }
    

    
    
    
}
