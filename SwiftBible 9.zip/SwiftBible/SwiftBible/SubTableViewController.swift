//
//  SubTableViewController.swift
//  Bible
//
//  Created by Pio on 11/1/19.
//  Copyright © 2019 pio. All rights reserved.
//

import UIKit

class SubTableViewController: UITableViewController,UITextFieldDelegate {

    @IBOutlet weak var txtSearchBar: UITextField!
    
    
    var bibleChapterArr : [Bibles] = []
    var bibleChapterSearchArr : [Bibles] = []
    var cntBook = 0
    var cntVerse = 0
    var cntChapter = 0
    var searchbible = false
    var myData : MyData!
    var verseToSearch : String?
    var bibleOldArr : [Bibles] =  []
    var bibleNewArr : [Bibles] =  []
    
    var bibleArr : [Bibles] =  []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = myData.name
        
                OpenSubBible()
        
        txtSearchBar.delegate = self
        txtSearchBar.addTarget(self, action: #selector(searchRecords(_ :)), for: .editingChanged)
        
        // addNavBarImage()
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .action, target: self, action: #selector(share))
        navigationItem.rightBarButtonItem?.isEnabled = false
        
    }
    
    //MARK:- UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtSearchBar.resignFirstResponder()
        return true
    }
    //MARK:- searchRecords
    @objc func searchRecords(_ textField: UITextField) {
        //
        self.bibleChapterArr.removeAll()
        if textField.text?.count != 0 {
            for arr in bibleChapterSearchArr{
                if let chapterToSearch = textField.text{
                    let range = arr.chapters.lowercased().range(of: chapterToSearch, options: .caseInsensitive, range: nil, locale: nil)
                    if range != nil {
                        
                        self.bibleChapterArr.append(arr)
                        searchbible = true
                        navigationItem.rightBarButtonItem?.isEnabled = true
                    }
                }
            }
        }
        else {
            for arr in bibleChapterSearchArr {
                bibleChapterArr.append(arr)
                searchbible = false
                navigationItem.rightBarButtonItem?.isEnabled = false
            }
        }
        
        self.tableView.reloadData()
    }
    
    @objc func share() {
        let activity = UIActivityIndicatorView(style: .whiteLarge)
        activity.color = UIColor.blue
        self.view.addSubview(activity)
        activity.frame = self.view.frame
        activity.center = self.view.center
        activity.startAnimating()
        performSegue(withIdentifier: "SubToView", sender:  (bibleChapterArr))
        activity.stopAnimating()
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        
        if segue.identifier == "SubToChapter" {
            let destVC = segue.destination as! ChapterCollectionViewController
            destVC.myData = (sender as! MyData)
        }
        
        if segue.identifier == "SubToView" && searchbible == true {
            let destVC = segue.destination as! ViewController
            
            destVC.bibleChapterArr = (sender as! [Bibles])
            //destVC.myData = (sender as! MyData)
            
        }
        
    }
    
    
    
    func OpenSubBible(){
        let activity = UIActivityIndicatorView(style: .whiteLarge)
        activity.color = UIColor.blue
        self.view.addSubview(activity)
        activity.frame = self.view.frame
        activity.center = self.view.center
        activity.startAnimating()
        
        let path = Bundle.main.path(forResource: "en_kjv", ofType: "json")
        let url = URL(fileURLWithPath: path!)
        
        //let url = URL(string: "https://restcountries.eu/rest/v2/all")
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else { return }
            do{
                let json = try JSON(data:data)
                //print(json)
                let results = json[]
                var i:Int = 0
                // var j:Int = 0
                // var book = 0
                var chapter = 0
                var verses = 0
                
                //var i = 0
                
                // DispatchQueue.global().async {
                
                for arr in results.arrayValue{
                    for (key,value) in arr {
                        
                        if key == "abbrev" {
                            //print("\(self.cntBook)---\(value)")
                            self.cntBook += 1
                        }
                        if key == "chapters" {
                            //   self.bibleChapterArr.append("\(value)")
                            // self.bibleChapterSearchArr.append("\(value)")
                            
                        }
                        if key == "name" {
                            let bible  = Bibles(book: i,name:"\(value)",chapters:"\(value)",chapter: i, verse: i, title: "")
                            //print ("\(key)")
                            // print ("\(value)")
                            self.bibleArr.append(bible)
                            if i < 39 {
                                
                                self.bibleOldArr.append(bible)
                            }
                            else {
                                self.bibleNewArr.append(bible)
                            }
                            
                            //print ("\(i)---\(value)")
                        }
                        
                    }
                    i += 1
                }
                
                //}
                
                //DispatchQueue.main.async {
                //self.tableView.reloadData()
                //   activity.stopAnimating()
                //}
                
                i = 0
                
                
        
               // var k = self.myData.chapter
                
                
                
                // activity.startAnimating()
                // DispatchQueue.global().async {
                for k in 0...(self.cntBook) {
                    chapter = 0
                    for arr in results[k,"chapters"].arrayValue{
                        for (key,value) in arr {
                            
                            // print ("---\(key) -- \(value)----")
                            //no of verses
                            if Int(key) == 0 {
                                verses = 0
                            }
                            
                            
                            let bible  = Bibles(book: k,name: self.bibleArr[k].name ,chapters: "\(value)",chapter: chapter, verse: verses, title: "")
                            self.bibleChapterArr.append(bible)
                            
                            let biblesearch  = Bibles(book: k,name: self.bibleArr[k].name, chapters: "\(value)", chapter: chapter, verse: verses, title: "")
                            
                            self.bibleChapterSearchArr.append(biblesearch)
                            
                            verses += 1
                            
                           //       print("book: \(self.book), chapter : \(chapter) verse : \(verses)  key : \(key)")
                        }
                        //no of chapter
                        ///    print("book: \(self.book), chapter : \(chapter) verse : \(verses)  key : \(key)")
                        
                        chapter += 1
                    }
                    
                    // print("book: \(self.book), chapter : \(chapter) verse : \(verses)  key : \(key)")
                    //no of book
                }
                
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                    activity.stopAnimating()
                    
                }
            }catch{
                print(error.localizedDescription)
            }
            }.resume()
        
    }

    // MARK: - Table view data source
    
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if searchbible {
           return bibleChapterArr.count
        }
        else {
                    if myData.book == 0 {
                        return self.bibleOldArr.count
                    }
                    else {
                        return self.bibleNewArr.count
                    }
        }
    
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        var cell = tableView.dequeueReusableCell(withIdentifier: "SubCell") as! SubTableViewCell
        
        if searchbible {
            cell.SetCell(row: indexPath.row,chapter: self.bibleChapterArr[indexPath.row].chapters)
            title = txtSearchBar.text
            self.bibleChapterArr[indexPath.row].title = title!
            
            
        }
        else {
            if myData.book == 0 {
                cell.SetCell(row: indexPath.row,chapter: self.bibleOldArr[indexPath.row].name)
            }
            else {
                //let cell = tableView.dequeueReusableCell(withIdentifier: "SubCell") as! SubTableViewCell
                cell.SetCell(row: indexPath.row,chapter: self.bibleNewArr[indexPath.row].name)
                
            }
        }
          return cell
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    
        if myData.book == 1 {
            myData.chapter = 39 + indexPath.row
            myData.name = self.bibleNewArr[indexPath.row].name
        }
        else {
            myData.chapter = indexPath.row
             myData.name = self.bibleOldArr[indexPath.row].name
        }
        performSegue(withIdentifier: "SubToChapter", sender:  (myData))
        
    
    }
}


/*
 if i < 39 {
 self.bibleOldArr.append(bible)
 }
 else {
 self.bibleNewArr.append(bible)
 }
 
 */



