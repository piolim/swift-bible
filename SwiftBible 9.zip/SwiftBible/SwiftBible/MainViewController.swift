//
//  MainViewController.swift
//  SwiftBible
//
//  Created by Pio on 14/1/19.
//  Copyright © 2019 Pio. All rights reserved.
//

import UIKit

class MainViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var txtSearchBar: UITextField!
    
    var bibleChapterArr : [Bibles] = []
    var bibleChapterSearchArr : [Bibles] = []
    var cntBook = 0
    var cntVerse = 0
    var cntChapter = 0
    var searchbible = false
    var myData : MyData!
    var verseToSearch : String?
    var bibleArr : [Bibles] =  []
    var bibleSearchArr : [Bibles] =  []
    var mainBible = ["Old Testament","New Testament"]
    
  //  var  dontsearch = rue
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Swift Bible"
     //customizeButtonG1(buttonName: buttonName)
    // customizeButtonG1(buttonName: NTBtn)
        OTBtn()
        NTBtn()
        
        
    }
    
    var otBTN: UIButton!
    var ntBtn: UIButton!
   
     func OTBtn(){
          otBTN = UIButton.init(type: .system)
             otBTN.setTitle(mainBible[0], for: .normal)
             otBTN.addTarget(self, action: #selector(buttonClicked(_ :)), for: .touchUpInside)
          self.view.addSubview(otBTN)
         customizeButtonG1(buttonName: otBTN)
          
          // Disable Auto Resizing constraints
          otBTN.translatesAutoresizingMaskIntoConstraints = false

          let leftButtonnEdgeConstraint = NSLayoutConstraint(item: otBTN, attribute: NSLayoutConstraint.Attribute.left,relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.left
               , multiplier: 1.0, constant: 50)
          // right edge
          let rightButtonEageconstraint = NSLayoutConstraint(item: otBTN, attribute: NSLayoutConstraint.Attribute.right,relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.right, multiplier: 1.0, constant: -50)
          
          let topButtonconstraint = NSLayoutConstraint(item: otBTN, attribute: NSLayoutConstraint.Attribute.top,relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.top, multiplier: 1.0, constant: 300)
          
          //NsLaynut Relatinn.
          //Equal, tnlten: view, attribute: NSLayoutAttribte.Bntton1largin, lltiplierz 1.0, constant: -26)

          view.addConstraints([leftButtonnEdgeConstraint,rightButtonEageconstraint,topButtonconstraint])
          
          
     }
     
     @objc func buttonClicked(_ : UIButton) {
          print(mainBible[0])
          myData = MyData.init(name: mainBible[0], book: 0, chapter: 0, verse: 0, indexPath: [0,0])
        
        
       
          performSegue(withIdentifier: "MainViewToSub", sender:  (myData))
            
     }

    
       func NTBtn(){
        ntBtn = UIButton.init(type: .system)
        ntBtn.setTitle(mainBible[1], for: .normal)
        ntBtn.addTarget(self, action: #selector(ntbtnClicked(_ :)), for: .touchUpInside)
        self.view.addSubview(ntBtn)
        customizeButtonG1(buttonName: ntBtn)
        
        // Disable Auto Resizing constraints
        ntBtn.translatesAutoresizingMaskIntoConstraints = false
        // let t edge
        let leftButtonnEdgeConstraint = NSLayoutConstraint(item: ntBtn, attribute: NSLayoutConstraint.Attribute.left,relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.left
            , multiplier: 1.0, constant: 50)
        // right edge
        let rightButtonEageconstraint = NSLayoutConstraint(item: ntBtn, attribute: NSLayoutConstraint.Attribute.right,relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.right, multiplier: 1.0, constant: -50)
        
        let bottomButtonconstraint = NSLayoutConstraint(item: ntBtn, attribute: NSLayoutConstraint.Attribute.bottom,relatedBy: NSLayoutConstraint.Relation.equal, toItem: view, attribute: NSLayoutConstraint.Attribute.bottom, multiplier: 1.0, constant: -300)
        
    view.addConstraints([leftButtonnEdgeConstraint,rightButtonEageconstraint,bottomButtonconstraint])
        
        
    }
    
    @objc func ntbtnClicked(_ : UIButton) {
        print(mainBible[1])
        myData = MyData.init(name: mainBible[1], book: 1, chapter: 0, verse: 0, indexPath: [0,0])
        
        performSegue(withIdentifier: "MainViewToSub", sender:  (myData))
    }

    
 
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
      
    
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination
        
        // Pass the selected object to the new view controller.
        
        
        if segue.identifier == "MainViewToSub" {
            let destVC = segue.destination as! SubTableViewController
            destVC.myData = (sender as! MyData)
        }
        
        //}
             
    }
    
    func customizeButtonG1(buttonName:UIButton) {
        // change UIbutton propertie
        let c1GreenColor = (UIColor(red: -0.108958, green: 0.714926, blue: 0.758113, alpha: 1.0))
        let c2GreenColor = (UIColor(red: 0.108958, green: 0.714926, blue: 0.758113, alpha: 1.0))
        buttonName.backgroundColor = UIColor.blue
        buttonName.layer.cornerRadius = 15
        buttonName.layer.borderWidth = 0.8
        buttonName.layer.borderColor = c1GreenColor.cgColor
        
        buttonName.layer.shadowColor = c2GreenColor.cgColor
        buttonName.layer.shadowOpacity = 0.8
        buttonName.layer.shadowRadius = 12
        buttonName.layer.shadowOffset = CGSize(width: 1/2, height: 1/2)
        
         buttonName.layer.borderWidth = -50.0
         buttonName.titleLabel?.textColor = UIColor.white
        buttonName.tintColor = UIColor.yellow
         buttonName.titleLabel?.font = UIFont.systemFont(ofSize: 22)
         ///buttonName.
        //buttonName.setImage(UIImage(named:"3d-glass-refresh-32X32.png"), for: .normal)
        //buttonName.imageEdgeInsets = UIEdgeInsets(top: 6,left: 100,bottom: 6,right: 14)
        //buttonName.titleEdgeInsets = UIEdgeInsets(top: 0,left: -30,bottom: 0,right: 34)
        
    }
    


}


